﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace StudentMaster
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //Normal procedure
            cmd = new SqlCommand("SELECT * FROM Student_Master WHERE Stud_Code = @scode", con);



            //Using Stored Procedure
            //cmd = new SqlCommand("usp_SearchStudent1724171", con);
            //cmd.CommandType = CommandType.StoredProcedure;




            cmd.Parameters.AddWithValue("@scode", txtStudCode.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
           
            if (dr.HasRows)
            {
                lblName.Visible = true;
                lblScode.Visible = true;
                lblDCode.Visible = true;
                lblDob.Visible = true;
                lblAddress.Visible = true;

                txtName.Visible = true;
                txtStudCode.Visible = true;
                txtDcode.Visible = true;
                txtDob.Visible = true;
                txtAddress.Visible = true;

                btnDelete.Visible = true;
                btnUpdate.Visible = true;

               dr.Read();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDcode.Text = dr["Dept_Code"].ToString();
                txtDob.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student not found');</script>");
            }
            con.Close();
        }
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //using normal process
         // cmd = new SqlCommand("Update Student_master SET Stud_Name = @sname, Dept_Code = @dcode, Stud_Dob = @dob, Address = @address WHERE Stud_Code = @scode", con);



            cmd = new SqlCommand("usp_UpdateStudent172417121", con);
            cmd.CommandType = CommandType.StoredProcedure;



            //cmd.Parameters.AddWithValue("@sname", txtName.Text);
            cmd.Parameters.AddWithValue("@dcode", txtDcode.Text);
            cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@scode", txtStudCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert(' Student Data Updated Successfully');</script>");
                Response.Redirect("Home.aspx");
            }
            else { 
                Response.Write("<script type='text/javascript'>alert(' Student Data not updated');</script>");
        }

        }
    

        protected void Delete_Click(object sender, EventArgs e)
        {
            //cmd = new SqlCommand("DELETE FROM Student_Master WHERE Stud_Code = @scode", con);

            cmd = new SqlCommand("usp_DeleteStudent1724171", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.AddWithValue("@scode", txtStudCode.Text);
            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('New Student Deleted Successfully');</script>");
                Response.Redirect("Home.aspx");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert(' Student not deleted');</script>");
            }
        }
    }
}

   
        
    
    

  
    
