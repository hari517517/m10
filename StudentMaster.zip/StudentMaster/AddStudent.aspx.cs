﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Text;

namespace StudentMaster
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("INSERT INTO Student_Master (Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address) VALUES(@scode, @sname, @dcode, @dob, @address)", con);
            cmd.Parameters.AddWithValue("@scode", txtStudCode.Text);
            cmd.Parameters.AddWithValue("@sname", txtName.Text);
            cmd.Parameters.AddWithValue("@dcode", txtDcode.Text);
            cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@address", txtAddress.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('New Student Added Successfully');</script>");
                //Response.Redirect("Home.aspx");
                Server.Transfer("Home.aspx");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('New Student not added');</script>");
            }
        }

        

        protected void cusCustom_ServerValidate1(object source, ServerValidateEventArgs args)
        {
            if (txtAddress.Text == "Pune" || txtAddress.Text == "Hyderabad" || txtAddress.Text == "Bangalore")
            {
                args.IsValid = true;
            }

            else
            {
                args.IsValid = false;
            }
        }
    }
}


