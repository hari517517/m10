CREATE PROC usp_DisplayStudent172417
AS
BEGIN
	SELECT * FROM Student_Master
END
go




ALTER TABLE Student_Master
   ALTER COLUMN  Stud_Dob DateTime

CREATE PROC usp_SearchStudent1724171
(
	@scode		INT
)
AS
BEGIN
	SELECT * FROM Student_Master
	WHERE Stud_Code = @scode
END

GO

CREATE PROC usp_DeleteStudent1724171
(
	@Scode		INT
)
AS
BEGIN
	DELETE FROM Student_Master
	WHERE Stud_Code = @Scode
END

GO




CREATE PROC usp_UpdateStudent172417121
(
	@scode		INT,
	@dcode		INT,
	@address		VARCHAR(50),
	@dob    datetime

)
AS
BEGIN
	UPDATE Student_Master
	SET Address = @address,
		Dept_Code = @dcode,
		stud_dob=@dob
	WHERE Stud_Code = @scode
END

GO


